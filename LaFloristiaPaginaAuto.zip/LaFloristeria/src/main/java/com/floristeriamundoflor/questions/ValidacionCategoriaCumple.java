package com.floristeriamundoflor.questions;

import com.floristeriamundoflor.ui.CategoriaCumpleañosValidacion;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ValidacionCategoriaCumple implements Question {
    @Override
    public Boolean answeredBy(Actor actor) {
        return CategoriaCumpleañosValidacion.NOMBRE_PRODUCTO.resolveFor(actor).isVisible();
    }

    public static Question Validacion(){
        return new ValidacionCategoriaCumple();
    }
}
